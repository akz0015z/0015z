/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.passwordmanager;

/**
 *
 * @author emman
 */
import java.util.HashMap;
import javax.crypto.SecretKey;
import java.util.Base64;

public class LoginManager {
    private final HashMap<String, User> users = new HashMap<>();

    public void register(String username, String password) throws Exception {
        byte[] salt = SecurityUtility.generateSalt();
        String hashedPassword = SecurityUtility.hashPassword(password, salt);
        SecretKey aesKey = EncryptionUtility.generateAESKey();
        User user = new User(username, hashedPassword, salt, aesKey);
        users.put(username, user);
        
        // This is us debugging the code to see the output messages of the encryption
        System.out.println("The Original Password: " + password);
        System.out.println("The Salt (Base64): " + Base64.getEncoder().encodeToString(salt));
        System.out.println("The Hashed Password: " + hashedPassword);

        System.out.println("You are now registered successfully!!.");
    }

    public boolean login(String username, String password) throws Exception {
        User user = users.get(username);
        if (user != null) {
            String hashedPassword = SecurityUtility.hashPassword(password, user.getSalt());
            if (hashedPassword.equals(user.getPasswordHash())) {
                System.out.println("Great, You're Login was successful!.");
                return true;
            }
        }
        System.out.println("Oops, Invalid username or password.");
        return false;
    }

    public void addPassword(String username, String account, String password) throws Exception {
        User user = users.get(username);
        if (user != null) {
            // this iw where it encrpypts the password before storing it
            String encryptedPassword = EncryptionUtility.encrypt(password, user.getAesKey());
            user.getPasswords().put(account, encryptedPassword);
            
            // this are the statements to verify encryption
            System.out.println("Here is the Original User's accounts Password!: " + password);
            System.out.println("Here is the Encrypted Account Password!: " + encryptedPassword);

            System.out.println("Okay, You're Password was saved successfully!.");
        }
    }

    public String retrievePassword(String username, String account) throws Exception {
        User user = users.get(username);
        if (user != null && user.getPasswords().containsKey(account)) {
            // this is it decrypting the stored password before returning it
            String decryptedPassword = EncryptionUtility.decrypt(user.getPasswords().get(account), user.getAesKey());
            System.out.println("Here is the Decrypted User's Password!: " + decryptedPassword);
            return decryptedPassword;
        }
        return null;
    }
}
