/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.passwordmanager;

/**
 *
 * @author emman
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainGUI extends JFrame {
    private final LoginManager loginManager;
    private String currentUsername = null;
    private boolean loggedIn = false;

    public MainGUI() {
        loginManager = new LoginManager(); // This is where we start the Login Manager
        
        setTitle("Password Manager");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // My background color preference for the main panel
        JPanel panel = new JPanel();
        panel.setBackground(Color.GRAY); 
        panel.setLayout(new GridLayout(4, 1, 10, 10));

        // This is the code to create the buttons for the GUI that appears when you run
        JButton registerButton = createCustomButton("Click here to Register");
        JButton loginButton = createCustomButton("Click here to Login");
        JButton addPasswordButton = createCustomButton("Click here to Add Password");
        JButton retrievePasswordButton = createCustomButton("Click here to Retrieve Password");

        // This is where the code is for the buttons to work
        registerButton.addActionListener(new RegisterListener());
        loginButton.addActionListener(new LoginListener());
        addPasswordButton.addActionListener(new AddPasswordListener());
        retrievePasswordButton.addActionListener(new RetrievePasswordListener());

        // This is where i add buttons to the panel
        panel.add(registerButton);
        panel.add(loginButton);
        panel.add(addPasswordButton);
        panel.add(retrievePasswordButton);

        // added panel to the frame
        add(panel);
    }

    // this is my customized button
    private JButton createCustomButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(Color.BLACK); // Set button color to black
        button.setForeground(new Color(135, 206, 250)); // Set font color to sky blue
        button.setFont(new Font("Arial", Font.BOLD, 14)); // Customize font
        return button;
    }

    // this is my customized input dialog
    private String showCustomInputDialog(String message) {
        JPanel panel = new JPanel();
        panel.setBackground(Color.GRAY);
        JLabel label = new JLabel(message);
        label.setForeground(new Color(135, 206, 250));
        label.setFont(new Font("Arial", Font.BOLD, 14));
        JTextField textField = new JTextField(10);
        textField.setBackground(Color.BLACK);
        textField.setForeground(new Color(135, 206, 250));
        textField.setCaretColor(new Color(135, 206, 250));
        panel.add(label);
        panel.add(textField);
        int result = JOptionPane.showConfirmDialog(this, panel, "Input", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            return textField.getText();
        }
        return null;
    }

    // this is my custom message dialog
    private void showCustomMessageDialog(String message) {
        JPanel panel = new JPanel();
        panel.setBackground(Color.GRAY);
        JLabel label = new JLabel(message);
        label.setForeground(new Color(135, 206, 250)); // Sky blue font color
        label.setFont(new Font("Arial", Font.BOLD, 14)); // Font style
        panel.add(label);
        JOptionPane.showMessageDialog(this, panel, "Message", JOptionPane.PLAIN_MESSAGE);
    }

    // Listener classes for each action
    private class RegisterListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String username = showCustomInputDialog("Enter Username:");
            String password = showCustomInputDialog("Enter Password:");
            if (username != null && password != null) {
                try {
                    loginManager.register(username, password);
                    showCustomMessageDialog("User registered successfully!");
                } catch (Exception ex) {
                    showCustomMessageDialog("Registration failed: " + ex.getMessage());
                }
            }
        }
    }

    private class LoginListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String username = showCustomInputDialog("Enter Username:");
            String password = showCustomInputDialog("Enter Password:");
            if (username != null && password != null) {
                try {
                    loggedIn = loginManager.login(username, password);
                    if (loggedIn) {
                        currentUsername = username;
                        showCustomMessageDialog("Login successful!");
                    } else {
                        showCustomMessageDialog("Invalid username or password.");
                    }
                } catch (Exception ex) {
                    showCustomMessageDialog("Login failed: " + ex.getMessage());
                }
            }
        }
    }

    private class AddPasswordListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (loggedIn) {
                String account = showCustomInputDialog("Enter Account Name:");
                String accountPassword = showCustomInputDialog("Enter Password for Account:");
                if (account != null && accountPassword != null) {
                    try {
                        loginManager.addPassword(currentUsername, account, accountPassword);
                        showCustomMessageDialog("Password saved successfully!");
                    } catch (Exception ex) {
                        showCustomMessageDialog("Failed to save password: " + ex.getMessage());
                    }
                }
            } else {
                showCustomMessageDialog("Please log in first.");
            }
        }
    }

    private class RetrievePasswordListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (loggedIn) {
                String account = showCustomInputDialog("Enter Account Name to Retrieve Password:");
                if (account != null) {
                    try {
                        String retrievedPassword = loginManager.retrievePassword(currentUsername, account);
                        if (retrievedPassword != null) {
                            showCustomMessageDialog("Password for " + account + ": " + retrievedPassword);
                        } else {
                            showCustomMessageDialog("Sorry there, There is no password found for that account.");
                        }
                    } catch (Exception ex) {
                        showCustomMessageDialog("Oops!, Failed to retrieve password: " + ex.getMessage());
                    }
                }
            } else {
                showCustomMessageDialog("Please log in first.");
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainGUI gui = new MainGUI();
            gui.setVisible(true);
        });
    }
}
