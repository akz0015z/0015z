/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.passwordmanager;

/**
 *
 * @author emman
 */
import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) throws Exception {
        LoginManager loginManager = new LoginManager();
        Scanner scanner = new Scanner(System.in);
        String username, password, account, storedPassword;
        boolean loggedIn = false;
        String currentUsername = null;  // This is where you store in the username

        while (true) {
            System.out.println("1. Register\n2. Login\n3. Add Password\n4. Retrieve Password\n5. Exit");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1 -> {
                    System.out.print("Please Enter username: ");
                    username = scanner.nextLine();
                    System.out.print("Please Enter password: ");
                    password = scanner.nextLine();
                    loginManager.register(username, password);
                }
                case 2 -> {
                    System.out.print("Please Enter username: ");
                    username = scanner.nextLine();
                    System.out.print("Please Enter password: ");
                    password = scanner.nextLine();
                    loggedIn = loginManager.login(username, password);
                    if (loggedIn) {
                        currentUsername = username;  //This sets the current username
                    }
                }
                case 3 -> {
                    if (loggedIn) {
                        System.out.print("Hello, Please Enter account name: ");
                        account = scanner.nextLine();
                        System.out.print("Hello, Please Enter password for the account: ");
                        storedPassword = scanner.nextLine();
                        loginManager.addPassword(currentUsername, account, storedPassword);
                    } else {
                        System.out.println("Hello!, Please login first.");
                    }
                }
                case 4 -> {
                    if (loggedIn) {
                        System.out.print("Okay so, account name to retrieve password: ");
                        account = scanner.nextLine();
                        String retrievedPassword = loginManager.retrievePassword(currentUsername, account);
                        if (retrievedPassword != null) {
                            System.out.println("Password for " + account + ": " + retrievedPassword);
                        } else {
                            System.out.println("Sorry!, There is No password found for that account.");
                        }
                    } else {
                        System.out.println("Sorry, Please login first.");
                    }
                }
                case 5 -> {
                    System.out.println("We are now.. Exiting.");
                    scanner.close();
                    return;
                }
                default -> System.out.println("Invalid choice.");
            }
        }
    }
}
