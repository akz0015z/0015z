/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.passwordmanager;

/**
 *
 * @author emman
 */
import javax.crypto.SecretKey;
import java.util.HashMap;

public class User {
    private final String username;
    private final String passwordHash;
    private final byte[] salt;
    private final SecretKey aesKey;
    private final HashMap<String, String> passwords = new HashMap<>();

    public User(String username, String passwordHash, byte[] salt, SecretKey aesKey) {
        this.username = username;
        this.passwordHash = passwordHash;
        this.salt = salt;
        this.aesKey = aesKey;
    }

    public String getUsername() { return username; }
    public String getPasswordHash() { return passwordHash; }
    public byte[] getSalt() { return salt; }
    public SecretKey getAesKey() { return aesKey; }
    public HashMap<String, String> getPasswords() { return passwords; }
}

