
const workouts = {
  Hypertrophy: {
    Chest: ["Barbell Bench Press, Dumbbell Bench Press, Alternating Dumbbell Bench Press, Hips-Off, Single-Arm Bench Press, Cable Crossover","Incline Dumbbell Press, Dumbbell Half Fly, Dumbbell Fly, Incline Dumbbell Fly, Low-Incline Press"],
    Back: ["Barbell Bent-over Row, Pull-up, Dumbbell Single-arm Row, Chest-supported Dumbbell Row,Inverted Row", "Barbell Deadlift Single-arm T-bar Rows, Farmer's Walk, Renegade Row, Superman, TRX Low Row, Med Ball Wood Chop, Good Mornings"],
    Arm: ["Biceps curl, Lateral raise, Triceps kickback, Overhead triceps extension, Rainbow slam, Kettlebell swing,", "Dumbbell pullover, Concentration curl, Twisting dumbbell curl, Underhand seated row, Reverse curl straight bar,","Leant forward EZ bar curl, Reverse Grip EZ bar curl, Prone Dumbbell Spider Curl, Incline Hammer Curl"],
    Abs: ["Barbell Floor Wiper, Medicine Ball Slam, Side Jackknife, Dragon Flag, Cable Woodchopper,", "Cocoon, Sandbag Sit-Up, Hanging Leg Raise, Superman With A Twist, Hollow Rocks, Barbell Roll Outs"," Russian Twists, Hollow Holds, Dumbbell Deadbugs, Bear Crawls"],
    Legs: [" Front Squat, Bulgarian Split Squat, Romanian Deadlift, Barbell Squat, Dumbbell Stepup, Deadlift,", "Swiss Ball Leg Curl, Single-leg Romanian Deadlift, Leg Press, Bodyweight Calf Raise, Walking Lunge,","Pause Squat, Reverse Lunge, Dumbbell Squat, Jump Squat"]
  },
  Strength: {
     Chest: ["Barbell Bench Press, Dumbbell Bench Press, Alternating Dumbbell Bench Press, Hips-Off, Single-Arm Bench Press, Cable Crossover","Incline Dumbbell Press, Dumbbell Half Fly, Dumbbell Fly, Incline Dumbbell Fly, Low-Incline Press"],
    Back: ["Barbell Bent-over Row, Pull-up, Dumbbell Single-arm Row, Chest-supported Dumbbell Row,Inverted Row", "Barbell Deadlift Single-arm T-bar Rows, Farmer's Walk, Renegade Row, Superman, TRX Low Row, Med Ball Wood Chop, Good Mornings"],
    Arm: ["Biceps curl, Lateral raise, Triceps kickback, Overhead triceps extension, Rainbow slam, Kettlebell swing,", "Dumbbell pullover, Concentration curl, Twisting dumbbell curl, Underhand seated row, Reverse curl straight bar,","Leant forward EZ bar curl, Reverse Grip EZ bar curl, Prone Dumbbell Spider Curl, Incline Hammer Curl"],
    Abs: ["Barbell Floor Wiper, Medicine Ball Slam, Side Jackknife, Dragon Flag, Cable Woodchopper,", "Cocoon, Sandbag Sit-Up, Hanging Leg Raise, Superman With A Twist, Hollow Rocks, Barbell Roll Outs"," Russian Twists, Hollow Holds, Dumbbell Deadbugs, Bear Crawls"],
    Legs: [" Front Squat, Bulgarian Split Squat, Romanian Deadlift, Barbell Squat, Dumbbell Stepup, Deadlift,", "Swiss Ball Leg Curl, Single-leg Romanian Deadlift, Leg Press, Bodyweight Calf Raise, Walking Lunge,","Pause Squat, Reverse Lunge, Dumbbell Squat, Jump Squat"]
  },
  Calisthenics: {
     Chest: ["Barbell Bench Press, Dumbbell Bench Press, Alternating Dumbbell Bench Press, Hips-Off, Single-Arm Bench Press, Cable Crossover","Incline Dumbbell Press, Dumbbell Half Fly, Dumbbell Fly, Incline Dumbbell Fly, Low-Incline Press"],
    Back: ["Barbell Bent-over Row, Pull-up, Dumbbell Single-arm Row, Chest-supported Dumbbell Row,Inverted Row", "Barbell Deadlift Single-arm T-bar Rows, Farmer's Walk, Renegade Row, Superman, TRX Low Row, Med Ball Wood Chop, Good Mornings"],
    Arm: ["Biceps curl, Lateral raise, Triceps kickback, Overhead triceps extension, Rainbow slam, Kettlebell swing,", "Dumbbell pullover, Concentration curl, Twisting dumbbell curl, Underhand seated row, Reverse curl straight bar,","Leant forward EZ bar curl, Reverse Grip EZ bar curl, Prone Dumbbell Spider Curl, Incline Hammer Curl"],
    Abs: ["Barbell Floor Wiper, Medicine Ball Slam, Side Jackknife, Dragon Flag, Cable Woodchopper,", "Cocoon, Sandbag Sit-Up, Hanging Leg Raise, Superman With A Twist, Hollow Rocks, Barbell Roll Outs"," Russian Twists, Hollow Holds, Dumbbell Deadbugs, Bear Crawls"],
    Legs: [" Front Squat, Bulgarian Split Squat, Romanian Deadlift, Barbell Squat, Dumbbell Stepup, Deadlift,", "Swiss Ball Leg Curl, Single-leg Romanian Deadlift, Leg Press, Bodyweight Calf Raise, Walking Lunge,","Pause Squat, Reverse Lunge, Dumbbell Squat, Jump Squat"]
  },
};

function getRandomInt(max) {
  return Math.floor(Math.random() * max);
}

function generateWorkout(workoutType, targetMuscles) {
  const generatedWorkouts = [];

  targetMuscles.forEach(targetMuscle => {
    const selectedWorkout = workouts[workoutType][targetMuscle];
    const randomIndex = getRandomInt(selectedWorkout.length);
    const workout = selectedWorkout[randomIndex];
    generatedWorkouts.push({ workout, targetMuscle });
  });

  displayGeneratedWorkouts(generatedWorkouts, workoutType);
}

function displayGeneratedWorkouts(workoutsList, workoutType) {
  const workoutDisplay = document.getElementById("workoutGeneration");
  let setsAndReps;
  
  switch (workoutType) {
    case 'Hypertrophy':
      setsAndReps = '4 sets 10 reps';
      break;
    case 'Strength':
      setsAndReps = '3 sets 3-5 reps';
      break;
    case 'Calisthenics':
      setsAndReps = '5 sets 20 reps';
      break;
    default:
      setsAndReps = '';
  }

  const workoutsHTML = workoutsList.map(({ workout, targetMuscle }) => {
    return `<p>${targetMuscle}: ${workout} - ${setsAndReps}</p>`;
  }).join('');

  workoutDisplay.innerHTML = workoutsHTML;
}

document.getElementById('generateWorkoutBtn').addEventListener('click', function () {
  const workoutType = document.querySelector('input[name="workoutType"]:checked').value;
  const targetMuscles = Array.from(document.querySelectorAll('input[name="targetMuscle"]:checked')).map(input => input.value);
  
  generateWorkout(workoutType, targetMuscles);
});
